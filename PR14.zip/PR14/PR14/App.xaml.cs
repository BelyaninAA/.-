﻿using System.Windows;

namespace CodeReviewSystem
{
    public partial class App : Application
    {
    }
}