﻿using System.Windows;

namespace CodeReviewSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow(string email, string name, int userId)
        {
            InitializeComponent();
            txtUserEmail.Text = email;
            txtUserName.Text = name;
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            LoginPage loginPage = new LoginPage();
            loginPage.Show();
            this.Close();
        }
    }
}