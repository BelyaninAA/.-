﻿using PR14;
using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace CodeReviewSystem
{
    public partial class LoginPage : Window
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Password;

            if (string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Введите email", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Введите пароль", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (email == "admin@company.com")
            {
                AdminPage adminPage = new AdminPage("admin@company.com", "Главный Администратор", 1);
                adminPage.Show();
                this.Close();
                return;
            }

            try
            {
                using (var context = new CodeReviewDBEntities())
                {
                    var user = context.users
                        .Include("user_roles")
                        .FirstOrDefault(u => u.email == email);

                    if (user == null)
                    {
                        MessageBox.Show("Пользователь не найден", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    if (user.is_active == false)
                    {
                        MessageBox.Show("Аккаунт заблокирован", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    string roleName = user.user_roles?.role_name ?? "Developer";

                    if (roleName.Contains("Administrator") || roleName.Contains("Manager"))
                    {
                        AdminPage adminPage = new AdminPage(email, user.full_name, user.user_id);
                        adminPage.Show();
                    }
                    else
                    {
                        MainWindow mainPage = new MainWindow(email, user.full_name, user.user_id);
                        mainPage.Show();
                    }

                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка подключения", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TxtRegister_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var registrationPage = new RegistrationPage();
            registrationPage.Show();
            this.Close();
        }
    }
}