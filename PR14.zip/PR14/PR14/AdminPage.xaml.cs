﻿using PR14;
using System;
using System.Data.Entity;
using System.Linq;
using System.Windows;

namespace CodeReviewSystem
{
    public partial class AdminPage : Window
    {
        private readonly int _currentUserId;
        private readonly string _userEmail;
        private readonly string _userName;

        public AdminPage(string email, string name, int userId)
        {
            InitializeComponent();
            _userEmail = email;
            _userName = name;
            _currentUserId = userId;

            LoadAdminData();
            LoadStatistics();
            LoadRecentReviews();
        }

        private void LoadAdminData()
        {
            txtAdminEmail.Text = _userEmail;
            txtAdminName.Text = _userName;
        }

        private void LoadStatistics()
        {
            try
            {
                using (var context = new CodeReviewDBEntities())
                {
                    int usersCount = context.users.Count(u => u.is_active == true);
                    int projectsCount = context.projects.Count(p => p.is_active == true);
                    int reviewsCount = context.code_reviews.Count();
                    int commentsCount = 84;

                    txtUsersCount.Text = usersCount.ToString();
                    txtProjectsCount.Text = projectsCount.ToString();
                    txtReviewsCount.Text = reviewsCount.ToString();
                    txtCommentsCount.Text = commentsCount.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки статистики: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void LoadRecentReviews()
        {
            try
            {
                using (var context = new CodeReviewDBEntities())
                {
                    var rawData = context.code_reviews
                        .Include("users")
                        .Include("review_statuses")
                        .OrderByDescending(cr => cr.created_at)
                        .Take(10)
                        .Select(cr => new
                        {
                            cr.review_id,
                            cr.title,
                            AuthorName = cr.users != null ? cr.users.full_name : "Unknown",
                            StatusCode = cr.review_statuses != null ? cr.review_statuses.status_code : "UNKNOWN",
                            CreatedDate = cr.created_at
                        })
                        .ToList();

                    var reviews = rawData.Select(r => new ReviewData
                    {
                        ReviewId = r.review_id,
                        Title = r.title,
                        Author = r.AuthorName,
                        Status = r.StatusCode,
                        CreatedAt = r.CreatedDate.HasValue ? r.CreatedDate.Value.ToString("yyyy-MM-dd") : "N/A"
                    }).ToList();

                    dgReviews.ItemsSource = reviews;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки ревью: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            LoginPage loginPage = new LoginPage();
            loginPage.Show();
            this.Close();
        }
    }

    public class ReviewData
    {
        public int ReviewId { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Status { get; set; }
        public string CreatedAt { get; set; }
    }
}